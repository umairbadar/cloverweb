package com.example.lubna.cloverweb;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Cart extends Fragment {
    ListView lview2;
    Button btn2;
    TextView cross;
    TextView text;
    String gettext2;
    Button backward,forward;
    private Button textviewamount2;
    int a;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final ViewGroup rootview = (ViewGroup) inflater.inflate(R.layout.cart, container, false);

        lview2 = rootview.findViewById(R.id.listcart);
        String[] ds = {"Rice","Pulses"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), R.layout.cartlisting,R.id.name_food,ds);
        lview2.setAdapter(adapter);
        textviewamount2 = rootview.findViewById(R.id.buttonprocedecheck);
        textviewamount2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getContext(),Checkout.class);
                startActivity(i);

            }

        });
        return rootview;
        }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);
        backward = view.findViewById(R.id.backword);
        forward = view.findViewById(R.id.buttonforward);
        text = view.findViewById(R.id.textviewtext);
    }

}
